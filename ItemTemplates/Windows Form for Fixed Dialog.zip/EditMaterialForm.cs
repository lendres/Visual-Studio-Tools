﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace $rootnamespace$
{
	/// <summary>
	/// 
	/// </summary>
	public partial class $safeitemname$ : Form
	{
		#region Members

		#endregion

		#region Construction

		public $safeitemname$()
		{
			InitializeComponent();
		}

		#endregion

		#region Properties

		#endregion

		#region Event Handlers

		#endregion

		#region Methods

		#endregion

	} // End class.
} // End namespace.